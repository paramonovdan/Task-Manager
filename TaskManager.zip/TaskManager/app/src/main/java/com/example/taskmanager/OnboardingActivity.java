package com.example.taskmanager;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class OnboardingActivity extends AppCompatActivity {

    private static final String PREF_NAME = "onboarding_pref";
    private static final String KEY_FIRST_LAUNCH = "is_first_launch";

    private TextView onboardingTitleTextView;
    private TextView onboardingDescriptionTextView;
    private ImageView onboardingImageView;
    private Button buttonPrevious;
    private Button buttonNext;
    private Button buttonFinish;

    private int currentStep = 0;

    private int[] titles = {
            R.string.onboarding_step1_title,
            R.string.onboarding_step2_title,
            R.string.onboarding_step3_title
    };

    private int[] descriptions = {
            R.string.onboarding_step1_description,
            R.string.onboarding_step2_description,
            R.string.onboarding_step3_description
    };

    private int[] images = {
            0,
            R.drawable.placeholder_add_task,
            R.drawable.placeholder_delete_task
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        boolean isFirstLaunch = prefs.getBoolean(KEY_FIRST_LAUNCH, true);

        if (!isFirstLaunch) {
            navigateToMainActivity();
            return;
        }

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_onboarding);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        onboardingTitleTextView = findViewById(R.id.onboardingTitleTextView);
        onboardingDescriptionTextView = findViewById(R.id.onboardingDescriptionTextView);
        onboardingImageView = findViewById(R.id.onboardingImageView);
        buttonPrevious = findViewById(R.id.buttonPrevious);
        buttonNext = findViewById(R.id.buttonNext);
        buttonFinish = findViewById(R.id.buttonFinish);

        buttonPrevious.setOnClickListener(v -> {
            currentStep--;
            updateOnboardingStep();
        });

        buttonNext.setOnClickListener(v -> {
            currentStep++;
            updateOnboardingStep();
        });

        buttonFinish.setOnClickListener(v -> {
            markOnboardingComplete();
            navigateToMainActivity();
        });

        updateOnboardingStep();
    }

    private void updateOnboardingStep() {
        onboardingTitleTextView.setText(titles[currentStep]);
        onboardingDescriptionTextView.setText(descriptions[currentStep]);

        if (currentStep == 0) {
            onboardingImageView.setVisibility(View.GONE);
        } else {
            onboardingImageView.setVisibility(View.VISIBLE);
            onboardingImageView.setImageResource(images[currentStep]);
        }

        if (currentStep == titles.length - 1) {
            buttonNext.setVisibility(View.GONE);
            buttonFinish.setVisibility(View.VISIBLE);
        } else {
            buttonNext.setVisibility(View.VISIBLE);
            buttonFinish.setVisibility(View.GONE);
        }
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(OnboardingActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void markOnboardingComplete() {
        SharedPreferences prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_FIRST_LAUNCH, false);
        editor.apply();
    }
}